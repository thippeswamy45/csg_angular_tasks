

export class User{
    taskListArray=[];
    textdata:any;
    checkFlag=[];
}
